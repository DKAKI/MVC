package web;

import metier.CreditMetier;

public class CreditModel {
    private double montant;
    private int duree;
    private double taux;
    private double mensualite;
    public double getMontant(){
        return montant;
    }
    public int getDuree(){
        return duree;
    }
    public double getTaux(){
        return taux;
    }
    public double getMensualite(){
        return mensualite;
    }

    public void setMontant(double montant){
        this.montant=montant;
    }
    public void setMensualite(double mensualite){
        this.mensualite=mensualite;
    }
    public void setTaux(double taux){
        this.taux=taux;
    }
    public void setDuree(int duree){
        this.duree=duree;
    }

    public CreditModel(){
        super();
    }
    public CreditModel(Double montant,int duree,double taux,double mensualite){
        super();
        this.montant=montant;
        this.duree=duree;
        this.taux=taux;
        this.mensualite=mensualite;
    }
}
